/**
  ******************************************************************************
  * @file    stm32f1xx_it.c
  * @brief   中断服务函数
  ******************************************************************************
  */

#include "main.h"
#include "stm32f1xx_it.h"

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
  while (1)
  {
  }
}

void MemManage_Handler(void)
{
  while (1)
  {
  }
}

void BusFault_Handler(void)
{
  while (1)
  {
  }
}

void UsageFault_Handler(void)
{
  while (1)
  {
  }
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

void SysTick_Handler(void)
{
  HAL_IncTick();
}

/* TIM3 更新中断：交给 HAL 分派到 HAL_TIM_PeriodElapsedCallback */
void TIM3_IRQHandler(void)
{
  HAL_TIM_IRQHandler(&htim3);
}
