/**
  ******************************************************************************
  * @file    main.c
  * @brief   STM32F103C8T6 定时器与 PWM 呼吸灯实验（TIM3_CH1 / PA6）
  *
  * 演示模式：
  *   DEMO_MODE = 1：定时器计数方式，LED 亮 1 s、灭 1 s，完整周期 2 s
  *   DEMO_MODE = 2：PWM 呼吸灯，1 kHz PWM，占空比 0%→100%→0%，
  *                  完整呼吸周期约 2 s
  *
  * 定时器参数：
  *   定时器时钟 TIM3CLK = 72 MHz（APB1 分频后为 36 MHz，但定时器时钟倍频为 72 MHz）
  *   DEMO_MODE = 1：PSC=7199，ARR=9999，更新频率 1 Hz，中断里翻转 PA6
  *   DEMO_MODE = 2：PSC=71，ARR=999，PWM 频率 1 kHz，CCR=0~1000 调占空比
  ******************************************************************************
  */

#include "main.h"

#define DEMO_MODE                 1U   /* 1=定时器闪烁，2=PWM 呼吸灯 */

#define BREATH_STEP_MS            10U  /* 每 10 ms 改变一次占空比 */
#define BREATH_STEPS              100U /* 0%→100% 共 100 级，半周期约 1 s */
#define PWM_FULL_SCALE            1000U/* ARR+1，占空比 100% 对应的 CCR */

TIM_HandleTypeDef htim3;

static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
#if (DEMO_MODE == 1U)
static void MX_TIM3_TimeBase_Init(void);
#else
static void MX_TIM3_PWM_Init(void);
#endif

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();

#if (DEMO_MODE == 1U)
  /* ---------------- 任务一：定时器计数方式，2 s 亮灭 ---------------- */
  MX_TIM3_TimeBase_Init();

  /* 启动 TIM3 更新中断。每 1 s 进入一次 HAL_TIM_PeriodElapsedCallback */
  if (HAL_TIM_Base_Start_IT(&htim3) != HAL_OK)
  {
    Error_Handler();
  }

  while (1)
  {
    /* 全部工作由定时器中断完成，主循环保持空闲 */
  }
#else
  /* ---------------- 任务二：PWM 呼吸灯 ---------------- */
  uint32_t n;
  uint32_t phase;
  uint32_t duty;

  MX_TIM3_PWM_Init();

  /* 先输出 0% 占空比，再启动 PWM，避免上电瞬间满亮度 */
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0U);
  if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  while (1)
  {
    /*
      一个完整呼吸周期共 200 个时间片，每片 10 ms，合计 2 s。
      n=0..100 时 phase 从 0 增到 100，n=101..199 时 phase 从 99 降到 1。
      duty = phase² × 1000 / 100²，低亮度区停留更久，视觉上比线性变化更柔和。
    */
    for (n = 0U; n < (2U * BREATH_STEPS); n++)
    {
      if (n <= BREATH_STEPS)
      {
        phase = n;
      }
      else
      {
        phase = (2U * BREATH_STEPS) - n;
      }

      duty = (phase * phase * PWM_FULL_SCALE) /
             (BREATH_STEPS * BREATH_STEPS);

      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, duty);
      HAL_Delay(BREATH_STEP_MS);
    }
  }
#endif
}

/* 系统时钟：HSE 8 MHz × 9 = 72 MHz，APB1=36 MHz，APB2=72 MHz */
static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK |
                                RCC_CLOCKTYPE_SYSCLK |
                                RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* PA6 初始化：任务一为普通推挽输出，任务二为复用推挽输出 */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_AFIO_CLK_ENABLE();

  /* 上电先让 LED 熄灭（高电平点亮接法） */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);

#if (DEMO_MODE == 1U)
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
#else
  /* TIM3_CH1 复用到 PA6，必须配置为 AF_PP */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
#endif
}

#if (DEMO_MODE == 1U)
/* 任务一：TIM3 纯定时器，1 Hz 更新中断 */
static void MX_TIM3_TimeBase_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  __HAL_RCC_TIM3_CLK_ENABLE();

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 7199U;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 9999U;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_NVIC_SetPriority(TIM3_IRQn, 2U, 0U);
  HAL_NVIC_EnableIRQ(TIM3_IRQn);
}
#else
/* 任务二：TIM3_CH1 PWM，1 kHz，占空比由 CCR1 决定 */
static void MX_TIM3_PWM_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  __HAL_RCC_TIM3_CLK_ENABLE();

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 71U;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999U;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0U;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
}
#endif

#if (DEMO_MODE == 1U)
/* TIM3 更新中断回调：每 1 s 翻转 PA6，所以 LED 亮 1 s、灭 1 s */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM3)
  {
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
  }
}
#endif

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
  while (1)
  {
  }
}
#endif

